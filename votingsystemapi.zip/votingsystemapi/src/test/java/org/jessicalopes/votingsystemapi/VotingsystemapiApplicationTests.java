package org.jessicalopes.votingsystemapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VotingsystemapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
