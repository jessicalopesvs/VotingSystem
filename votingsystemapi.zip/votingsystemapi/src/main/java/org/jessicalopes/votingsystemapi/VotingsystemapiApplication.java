package org.jessicalopes.votingsystemapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VotingsystemapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(VotingsystemapiApplication.class, args);
	}

}
