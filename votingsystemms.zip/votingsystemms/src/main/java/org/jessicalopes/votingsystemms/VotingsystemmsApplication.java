package org.jessicalopes.votingsystemms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VotingsystemmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(VotingsystemmsApplication.class, args);
	}

}
