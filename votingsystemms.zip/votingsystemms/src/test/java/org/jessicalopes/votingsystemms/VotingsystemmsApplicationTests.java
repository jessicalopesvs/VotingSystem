package org.jessicalopes.votingsystemms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VotingsystemmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
